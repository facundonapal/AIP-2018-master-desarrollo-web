﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Práctica 11</title>
</head>

<body>
<div align="center">
  <table width="82%" border="0" cellpadding="4">
    <tr> 
      <td width="19%"><font color="#0000FF" size="2">DECORACIÓN</font></td>
      <td width="51%" rowspan="5"><div align="center"><img src="images/nodisponible.gif"></div></td>
      <td width="30%"><font color="#FF0080" size="2">FLORES</font></td>
    </tr>
    <tr> 
      <td>Figurita de cisne</td>
      <td>Ramo flores 1</td>
    </tr>
    <tr> 
      <td>Despertador</td>
      <td>Ramo flores 2</td>
    </tr>
    <tr> 
      <td>Reloj de pared</td>
      <td>Ramo flores 3</td>
    </tr>
    <tr> 
      <td>Lámpara de pie</td>
      <td>Ramo flores 4</td>
    </tr>
  </table>
</div>
</body>
</html>
